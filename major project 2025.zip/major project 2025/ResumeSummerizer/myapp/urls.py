from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('',views.base,name='home'),

    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),

    path('resume_list/', views.resume_list, name='resume_list'),
    path('resumecreate/', views.resume_create, name='resume_create'),
    path('<int:pk>/update/', views.resume_update, name='resume_update'),
    path('<int:pk>/view/', views.resume_view, name='resume_view'),

    path('job_list/', views.job_list, name='job_list'),
    path('job_details/', views.job_details, name='job_details'),
    path('<int:pk>/details/', views.job_details, name='job_details'),
    path('jobcreate/', views.job_create, name='job_create'),
    path('<int:pk>/update/', views.job_update, name='job_update'),

    path('resumes/<int:pk>/delete/', views.resume_delete, name='resume_delete'),
    path('jobs/<int:pk>/delete/', views.job_delete, name='job_delete'),

    path('resumes/verified/', views.verified_resumes, name='verified_resumes'),
    path('resumes/pending/', views.resume_pending, name='resume_pending'),

    path('apply_to_job/', views.apply_to_job, name='apply_to_job'),
    path('resume/<int:resume_id>/analyze/', views.analyze_resume_view, name='analyze_resume'),

    # admin
    path('users/', views.user_list, name='user_list'),
    path('users/create/', views.user_create, name='user_create'),
    path('users/<int:pk>/update/', views.user_update, name='user_update'),
    path('users/<int:pk>/delete/', views.user_delete, name='user_delete'),
    path('users/verify_resumes/', views.verify_resumes, name='verify_resumes'),
    # user
    path('profile/', views.user_profile, name='profile'),
    path('profile/update/', views.update_profile, name='update_profile'),
    path('profile/delete/', views.delete_profile, name='delete_profile'),

    # company
    path('company_job_list/',views.company_job_list,name='company_job_list'),
]

urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

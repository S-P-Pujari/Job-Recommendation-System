from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import CustomUser, Resume, Job, JobApplication

# CustomUser Admin
class CustomUserAdmin(UserAdmin):
    model = CustomUser
    list_display = ('username', 'email', 'first_name', 'last_name', 'preferred_job_type', 'is_staff')
    list_filter = ('preferred_job_type', 'is_staff', 'is_active', 'groups')
    search_fields = ('username', 'email', 'first_name', 'last_name', 'preferred_job_type')
    ordering = ('username',)
    fieldsets = UserAdmin.fieldsets + (
        ('Custom Fields', {'fields': ('photo', 'preferred_job_type')}),
    )

# Resume Admin
# class ResumeAdmin1(admin.ModelAdmin):
#     list_display = ('name', 'email', 'phone', 'user')
#     search_fields = ('name', 'email', 'skills')
#     list_filter = ('user',)
#     ordering = ('name',)

class ResumeAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'cgpa', 'department', 'verified')
    list_filter = ('department', 'verified')
    actions = ['verify_resumes']

    def verify_resumes(self, request, queryset):
        queryset.update(verified=True)
        self.message_user(request, "Selected resumes have been verified.")
    verify_resumes.short_description = "Mark selected resumes as verified"

# Job Admin
class JobAdmin(admin.ModelAdmin):
    list_display = ('title', 'company_name', 'location', 'job_type', 'level', 'posted_date')
    search_fields = ('title', 'company_name', 'location', 'description')
    list_filter = ('job_type', 'level', 'location', 'posted_date')
    ordering = ('-posted_date',)

# JobApplication Admin
class JobApplicationAdmin(admin.ModelAdmin):
    list_display = ('user', 'job', 'applied_date')
    search_fields = ('user__username', 'job__title')
    list_filter = ('applied_date', 'job')
    ordering = ('-applied_date',)

# Register the models with the admin site
admin.site.register(CustomUser, CustomUserAdmin)
admin.site.register(Resume, ResumeAdmin)
admin.site.register(Job, JobAdmin)
admin.site.register(JobApplication, JobApplicationAdmin)

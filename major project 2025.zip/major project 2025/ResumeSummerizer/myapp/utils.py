import spacy
from sklearn.feature_extraction.text import CountVectorizer

# Load spaCy model (Install using: pip install spacy && python -m spacy download en_core_web_sm)
nlp = spacy.load("en_core_web_sm")

def analyze_resume(resume_text, preferred_job_type):
    # Example data for market trends
    market_trends = {
        "Software Developer": ["Python", "Django", "API Development", "SQL", "Cloud Computing"],
        "Data Scientist": ["Python", "Machine Learning", "Statistics", "Data Visualization", "SQL"],
    }

    recommendations = []

    # Extract skills from the resume
    doc = nlp(resume_text)
    extracted_skills = [ent.text for ent in doc.ents if ent.label_ == "SKILL"]

    # Compare extracted skills with market trends
    job_trends = market_trends.get(preferred_job_type, [])
    missing_skills = [skill for skill in job_trends if skill not in extracted_skills]

    # Add recommendations based on missing skills
    if missing_skills:
        recommendations.append(f"Consider learning these skills for {preferred_job_type}: {', '.join(missing_skills)}")

    # General recommendations
    if len(resume_text.split()) < 300:
        recommendations.append("Your resume is too short. Add more details about your experience and achievements.")

    return recommendations


def predict_job_type(resume_text):
    job_keywords = {
        'Developer': ['python', 'django', 'flask', 'java', 'javascript', 'html', 'css', 'react', 'node.js', 'ruby', 'c++', 'go', 'typescript'],
        'Designer': ['photoshop', 'illustrator', 'ux', 'ui', 'design', 'sketch', 'adobe', 'responsive', 'figma'],
        'Data Scientist': ['data analysis', 'python', 'r', 'machine learning', 'deep learning', 'tensorflow', 'pandas', 'numpy', 'sql'],
        'Project Manager': ['agile', 'scrum', 'project management', 'kanban', 'jira', 'leadership', 'team management'],
        'Business Analyst': ['business analysis', 'data analysis', 'reporting', 'excel', 'sql', 'stakeholder', 'requirements gathering'],
        'Marketing': ['seo', 'sem', 'content', 'social media', 'digital marketing', 'email marketing', 'advertising'],
        'DevOps': ['docker', 'kubernetes', 'aws', 'azure', 'gcp', 'terraform', 'jenkins', 'ci/cd'],
    }

    # Convert resume text to lowercase to handle case insensitivity
    resume_text = resume_text.lower()

    # Iterate through the job types and check if any keyword is found in the resume text
    for job_type, keywords in job_keywords.items():
        # Check if any keyword exists in the resume text
        if any(keyword.lower() in resume_text for keyword in keywords):  # Make keywords lowercase for case-insensitivity
            return job_type  # Return the matching job type

    return 'Unknown'  # If no match is found, return 'Unknown'

from django.contrib.auth.models import AbstractUser, Group, Permission
from django.db import models

class CustomUser(AbstractUser):
    photo = models.ImageField(upload_to='user_photos/', null=True, blank=True)
    preferred_job_type = models.CharField(max_length=100, null=True, blank=True)
    groups = models.ManyToManyField(
        Group,
        related_name="customuser_groups",  
        blank=True,
    )
    user_permissions = models.ManyToManyField(
        Permission,
        related_name="customuser_permissions",  
        blank=True,
    )

from django.db import models
from django.contrib.auth import get_user_model

CustomUser = get_user_model()

class Resume(models.Model):
    DEPARTMENT_CHOICES = [
        ('CS', 'Computer Science'),
        ('CIVIL', 'Civil Engineering'),
        ('MECH', 'Mechanical Engineering'),
        ('EC', 'Electronics and Communication'),
        # Add more departments as needed
    ]

    user = models.ForeignKey(
        CustomUser,
        on_delete=models.CASCADE,
        related_name='resumes'
    )
    name = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=15)
    summary = models.TextField()
    skills = models.TextField()
    experience = models.TextField()
    cgpa = models.FloatField(null=True)
    address = models.TextField(null=True)
    college_name = models.CharField(max_length=255, null=True)
    department = models.CharField(max_length=50, choices=DEPARTMENT_CHOICES,null=True)
    verified = models.BooleanField(default=False)
    

    def __str__(self):
        return f"{self.name} ({self.user.username})"

    

class Job(models.Model):
    title = models.CharField(max_length=255)
    location = models.CharField(max_length=255)
    salary = models.CharField(max_length=50)
    level = models.CharField(max_length=50, choices=[('Junior', 'Junior'), ('Senior', 'Senior'), ('Internship', 'Internship')])
    job_type = models.CharField(max_length=50, choices=[('Full Time', 'Full Time'), ('Part Time', 'Part Time'), ('Contract', 'Contract')])
    company_name = models.CharField(max_length=255)
    company_logo = models.ImageField(upload_to='company_logos/', blank=True, null=True)
    description = models.TextField()
    posted_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title


class JobApplication(models.Model):
    job = models.ForeignKey('Job', on_delete=models.CASCADE)
    user = models.ForeignKey(
        CustomUser,
        on_delete=models.CASCADE,
        related_name='jobapplication'
    )
    resume = models.ForeignKey(
        Resume,
        on_delete=models.CASCADE,
        related_name='job_applications'
    )
    applied_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} applied for {self.job.title}"

from django import forms
from .models import CustomUser

class UserProfileForm(forms.ModelForm):
    class Meta:
        model = CustomUser
        fields = ['first_name', 'last_name', 'email', 'photo', 'preferred_job_type']
        widgets = {
            'first_name': forms.TextInput(attrs={'class': 'form-control'}),
            'last_name': forms.TextInput(attrs={'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
            'photo': forms.ClearableFileInput(attrs={'class': 'form-control'}),
            'preferred_job_type': forms.TextInput(attrs={'class': 'form-control'}),
        }

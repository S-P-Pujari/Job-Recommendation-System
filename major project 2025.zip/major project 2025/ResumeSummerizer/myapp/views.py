from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate, logout
from django.contrib import messages
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from .models import *
from .forms import *
from .utils import *


def base(request):
    return render(request, 'base.html')

def register_view(request):
    if request.method == "POST":
        form = UserRegistrationForm(request.POST, request.FILES)
        if form.is_valid():
            user = form.save()
            messages.success(request, "Registration successful!")
            return redirect('login')
        else:
            messages.error(request, "Error during registration.")
    else:
        form = UserRegistrationForm()
    return render(request, 'accounts/register.html', {'form': form})

def login_view(request):
    if request.method == "POST":
        form = LoginForm(data=request.POST)
        if form.is_valid():
            user = authenticate(username=form.cleaned_data['username'], password=form.cleaned_data['password'])
            if user:
                login(request, user)
                return redirect('home')
        messages.error(request, "Invalid username or password.")
    else:
        form = LoginForm()
    return render(request, 'accounts/login.html', {'form': form})

def logout_view(request):
    logout(request)
    messages.success(request, "You have been logged out.")
    return redirect('login')

# resume

@login_required
def resume_list(request):
    """
    Displays a list of resumes for the currently logged-in user.
    """
    resumes = Resume.objects.filter(user=request.user)
    return render(request, 'resume/resume_list.html', {'resumes': resumes})

# @login_required
# def resume_create(request):
#     """
#     Handles the creation of a new resume for the logged-in user.
#     """
#     if request.method == 'POST':
#         form = ResumeForm(request.POST)
#         if form.is_valid():
#             resume = form.save(commit=False)
#             resume.user = request.user  # Associate resume with the current user
#             resume.save()
#             return redirect('resume_list')
#     else:
#         form = ResumeForm()
#     return render(request, 'resume/resume_form.html', {'form': form})

def resume_create(request):
    if request.method == 'POST':
        form = ResumeForm(request.POST)
        if form.is_valid():
            resume = form.save(commit=False)
            resume.user = request.user
            resume.verified = False  # Set as not verified initially
            resume.save()
            return redirect('resume_pending')  # Redirect to a pending confirmation page
    else:
        form = ResumeForm()
    return render(request, 'resume/resume_form.html', {'form': form})

def verified_resumes(request):
    resumes = Resume.objects.filter(verified=True)
    return render(request, 'resume/verified_resumes.html', {'resumes': resumes})

def resume_pending(request):
    return render(request, 'resume/resume_pending.html')


# Admin verification page
@login_required
def verify_resumes(request):
    # Get all resumes that are pending verification
    pending_resumes = Resume.objects.filter(verified=False)
    
    if request.method == 'POST':
        # Handle the verification (if an admin clicks "Verify")
        resume_id = request.POST.get('resume_id')
        resume = Resume.objects.get(id=resume_id)
        resume.verified = True
        resume.save()
        return redirect('verify_resumes')  # Redirect back to the verification page
    
    return render(request, 'admin/verify_resumes.html', {'pending_resumes': pending_resumes})

# ---------------------
@login_required
def resume_update(request, pk):
    """
    Handles updating an existing resume for the logged-in user.
    Ensures the user has permission to edit the resume.
    """
    resume = get_object_or_404(Resume, pk=pk, user=request.user)
    if request.method == 'POST':
        form = ResumeForm(request.POST, instance=resume)
        if form.is_valid():
            form.save()
            return redirect('resume_list')
    else:
        form = ResumeForm(instance=resume)
    return render(request, 'resume/resume_form.html', {'form': form})

@login_required
def resume_delete(request, pk):
    """
    Handles deleting a resume for the logged-in user.
    Ensures the user has permission to delete the resume.
    """
    resume = get_object_or_404(Resume, pk=pk, user=request.user)
    if request.method == 'POST':
        resume.delete()
        return redirect('resume_list')
    return render(request, 'resume/resume_confirm_delete.html', {'resume': resume})


@login_required
def resume_view(request, pk):
    """
    Displays the resume in a formatted view.
    """
    resume = get_object_or_404(Resume, pk=pk, user=request.user)
    skills_list = [skill.strip() for skill in resume.skills.split(',')]  
    return render(request, 'resume/resume_view.html', {'resume': resume, 'skills_list': skills_list})


# job
from django.shortcuts import render, get_object_or_404, redirect
from django.http import HttpResponse
from .models import Job
from .forms import JobForm

def job_list(request):
    """
    Display all job listings.
    """
    jobs = Job.objects.all()
    return render(request, 'job/joblistings.html', {'jobs': jobs})

def job_details(request, pk):
    """
    Display details of a specific job.
    """
    job = get_object_or_404(Job, pk=pk)
    return render(request, 'job/jobdetails.html', {'job': job})

from django.core.mail import send_mail
from django.shortcuts import render, get_object_or_404, redirect
from django.db.models.signals import post_save
from django.dispatch import receiver
from .forms import JobForm
from .models import Job

@receiver(post_save, sender=Job)
def send_job_notification(sender, instance, created, **kwargs):
    """
    Signal to send email notification when a job is created.
    """
    if created:
        subject = f"New Job Posted: {instance.title}"
        message = f"A new job titled '{instance.title}' has been posted. Check it out now!"
        from_email = "pujariswati118@gmail.com"
        
        # Send email to all users
        recipient_list = [user.email for user in CustomUser.objects.all() if user.email]
        if recipient_list:  # Ensure there are users to notify
            send_mail(subject, message, from_email, recipient_list)

from .models import CustomUser  # Make sure to import your CustomUser model

def job_create(request):
    """
    Create a new job and send email notification.
    """
    if request.method == 'POST':
        form = JobForm(request.POST, request.FILES)
        if form.is_valid():
            job = form.save()

            # Send notification email
            subject = f"New Job Posted: {job.title}"
            message = f"A new job titled '{job.title}' has been posted. Check it out now!"
            from_email = "pujariswati118@gmail.com"
            
            # Notify all users (CustomUser model)
            recipient_list = [user.email for user in CustomUser.objects.all() if user.email]
            if recipient_list:
                send_mail(subject, message, from_email, recipient_list)

            return redirect('job_list')
    else:
        form = JobForm()
    return render(request, 'job/jobform.html', {'form': form})


def job_update(request, pk):
    """
    Update an existing job and notify users about the update.
    """
    job = get_object_or_404(Job, pk=pk)
    if request.method == 'POST':
        form = JobForm(request.POST, request.FILES, instance=job)
        if form.is_valid():
            updated_job = form.save()

            # Notify users about job updates
            subject = f"Job Updated: {updated_job.title}"
            message = f"The job '{updated_job.title}' has been updated. Check it out now!"
            from_email = "pujariswati118@gmail.com"

            # Notify all users
            recipient_list = [user.email for user in CustomUser.objects.all() if user.email]
            if recipient_list:
                send_mail(subject, message, from_email, recipient_list)

            return redirect('job_list')
    else:
        form = JobForm(instance=job)
    return render(request, 'job/jobform.html', {'form': form})

def job_delete(request, pk):
    """
    Delete a job.
    """
    job = get_object_or_404(Job, pk=pk)
    if request.method == 'POST':
        job.delete()
        return redirect('job_list')
    return render(request, 'job/jobdelete.html', {'job': job})

# notification
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.core.mail import send_mail
from .models import Job
from django.contrib.auth.models import User

from django.core.mail import send_mail
from django.urls import reverse
from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import Job
from .models import CustomUser  # Assuming your custom user model is here

@receiver(post_save, sender=Job)
def send_job_notification(sender, instance, created, **kwargs):
    if created:
        # Generate job URL
        job_url = reverse('job_details', kwargs={'pk': instance.pk})
        full_job_url = f"http://localhost:8000{job_url}"  # Make sure to use the correct domain

        # Email content
        subject = f"New Job Posted: {instance.title}"
        message = (
            f"A new job titled '{instance.title}' has been posted.\n\n"
            f"Company: {instance.company_name}\n"
            f"Location: {instance.location}\n"
            f"Description: {instance.description[:100]}...\n\n"  # Limit description to 100 characters
            f"To apply and view more details, visit: {full_job_url}\n\n"
            f"Best regards,\nYour Job Portal"
        )

        from_email = "pujariswati118@gmail.com"
        
        # Send email to all users
        recipient_list = [user.email for user in CustomUser.objects.all() if user.email]
        if recipient_list:
            send_mail(subject, message, from_email, recipient_list)



from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from .models import Job, JobApplication
from .forms import JobApplicationForm


from charset_normalizer import from_bytes

from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import Job, Resume, JobApplication

@login_required
def apply_to_job(request):
    # Get the logged-in user's latest resume
    latest_resume = Resume.objects.filter(user=request.user).order_by('-id').first()

    # Get all available jobs
    jobs = Job.objects.all()

    if request.method == 'POST':
        # Retrieve selected job from the form
        job_id = request.POST.get('job_id')
        selected_job = get_object_or_404(Job, id=job_id)

        if not latest_resume:
            messages.error(request, "You don't have any resumes. Please create one before applying.")
            return redirect('apply_to_job')

        # Create a JobApplication instance
        job_application = JobApplication.objects.create(
            job=selected_job,
            user=request.user,
            resume=latest_resume,  # Using the latest resume
        )
        messages.success(request, f"Successfully applied to {selected_job.title}.")
        return redirect('apply_to_job')

    context = {
        'latest_resume': latest_resume,
        'jobs': jobs,
    }
    return render(request, 'job/apply_to_job.html', context)



from django.shortcuts import render
from .models import Resume, CustomUser
from .utils import analyze_resume, predict_job_type  # Assuming you have a utility function for prediction

@login_required
def analyze_resume_view(request, resume_id):
    # Get the resume and the user
    resume = Resume.objects.get(id=resume_id)
    user = request.user

    # Analyze the resume to predict the job type
    predicted_job_type = predict_job_type(resume.summary)  # This function would predict the job type based on the resume text

    # Save the predicted job type to the user's profile
    user.preferred_job_type = predicted_job_type
    user.save()

    # Get recommendations based on the predicted job type
    recommendations = analyze_resume(resume.summary, predicted_job_type)

    return render(request, 'job/analyze_resume.html', {
        'resume': resume,
        'recommendations': recommendations,
        'predicted_job_type': predicted_job_type
    })


# Admin
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import get_user_model
from django.contrib import messages
from .forms import UserRegistrationForm

CustomUser = get_user_model()

@login_required
def user_list(request):
    """
    List all users.
    """
    users = CustomUser.objects.all()
    return render(request, 'user/user_list.html', {'users': users})

@login_required
def user_create(request):
    """
    Create a new user.
    """
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, "User created successfully.")
            return redirect('user_list')
    else:
        form = UserRegistrationForm()
    return render(request, 'user/user_form.html', {'form': form, 'title': 'Create User'})

@login_required
def user_update(request, pk):
    """
    Update an existing user.
    """
    user = get_object_or_404(CustomUser, pk=pk)
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST, request.FILES, instance=user)
        if form.is_valid():
            form.save()
            messages.success(request, "User updated successfully.")
            return redirect('user_list')
    else:
        form = UserRegistrationForm(instance=user)
    return render(request, 'user/user_form.html', {'form': form, 'title': 'Update User'})

@login_required
def user_delete(request, pk):
    """
    Delete a user.
    """
    user = get_object_or_404(CustomUser, pk=pk)
    if request.method == 'POST':
        user.delete()
        messages.success(request, "User deleted successfully.")
        return redirect('user_list')
    return render(request, 'user/user_confirm_delete.html', {'user': user})

# user
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth import get_user_model
from django.contrib import messages
from .forms import UserRegistrationForm

CustomUser = get_user_model()

@login_required
def user_profile(request):
    """
    Display the logged-in user's profile.
    """
    return render(request, 'user/profile.html', {'user': request.user})

@login_required

@login_required
def update_profile(request):
    user = request.user
    if request.method == 'POST':
        form = UserProfileForm(request.POST, request.FILES, instance=user)
        if form.is_valid():
            form.save()
            return redirect('profile')  # Redirect to the profile page after updating
    else:
        form = UserProfileForm(instance=user)
    
    return render(request, 'user/update_profile.html', {'form': form})

@login_required
def delete_profile(request):
    """
    Allow the logged-in user to delete their profile.
    """
    user = request.user
    if request.method == 'POST':
        user.delete()
        messages.success(request, "Your profile has been deleted.")
        return redirect('home')  # Redirect to home or login page
    return render(request, 'user/profile_confirm_delete.html')

from django.shortcuts import render
from django.db.models import Q
from .models import Job, CustomUser

from django.shortcuts import render
from .models import Job

from django.shortcuts import render
from .models import JobApplication, Job, CustomUser, Resume

# def company_job_list(request):
#     # Get filter options
#     job_titles = Job.objects.values_list('title', flat=True).distinct()
#     job_types = CustomUser.objects.values_list('preferred_job_type', flat=True).distinct()
#     skills = Resume.objects.values_list('skills', flat=True).distinct()

#     # Retrieve filter criteria from the request
#     selected_title = request.GET.get('job_title')
#     selected_job_type = request.GET.get('preferred_job_type')
#     selected_skill = request.GET.get('skills')

#     # Filter the JobApplication table based on the selected filters
#     applications = JobApplication.objects.all()

#     if selected_title:
#         applications = applications.filter(job__title=selected_title)
#     if selected_job_type:
#         applications = applications.filter(user__preferred_job_type=selected_job_type)
#     if selected_skill:
#         applications = applications.filter(user__resumes__skills__icontains=selected_skill)

#     context = {
#         'applications': applications,
#         'job_titles': job_titles,
#         'job_types': job_types,
#         'skills': skills,
#         'selected_title': selected_title,
#         'selected_job_type': selected_job_type,
#         'selected_skill': selected_skill,
#     }
#     return render(request, 'job/job_list.html', context)

def company_job_list(request):
    # Get filter options
    job_titles = Job.objects.values_list('title', flat=True).distinct()
    job_types = CustomUser.objects.values_list('preferred_job_type', flat=True).distinct()
    skills = Resume.objects.values_list('skills', flat=True).distinct()

    # Retrieve filter criteria from the request
    selected_title = request.GET.get('job_title')
    selected_job_type = request.GET.get('preferred_job_type')
    selected_skill = request.GET.get('skills')

    # Filter the JobApplication table based on the selected filters
    applications = JobApplication.objects.all()

    if selected_title:
        applications = applications.filter(job__title=selected_title)
    if selected_job_type:
        applications = applications.filter(user__preferred_job_type=selected_job_type)
    if selected_skill:
        applications = applications.filter(user__resumes__skills__icontains=selected_skill)

    filtered_applications = []
    for application in applications:
        total_criteria = 0
        match_count = 0

        # Check job title
        if selected_title:
            total_criteria += 1
            if application.job.title == selected_title:
                match_count += 1

        # Check job type
        if selected_job_type:
            total_criteria += 1
            if application.user.preferred_job_type == selected_job_type:
                match_count += 1

        # Check skills
        # if selected_skill:
        #     total_criteria += 1
        #     if selected_skill.lower() in application.user.resumes.skills.lower():
        #         match_count += 1
                
        if selected_skill:
            total_criteria += 1
            # Check if any resume of the user contains the skill
            if application.user.resumes.filter(skills__icontains=selected_skill).exists():
                match_count += 1


        # Calculate match percentage
        actual_percentage = (match_count / total_criteria) * 100 if total_criteria > 0 else 0
        adjusted_percentage = 70 + (actual_percentage / 100) * (87 - 70)

        filtered_applications.append({
            'application': application,
            'match_percentage': round(adjusted_percentage, 2),
        })

    context = {
        'applications': filtered_applications,
        'job_titles': job_titles,
        'job_types': job_types,
        'skills': skills,
        'selected_title': selected_title,
        'selected_job_type': selected_job_type,
        'selected_skill': selected_skill,
    }
    return render(request, 'job/job_list.html', context)
